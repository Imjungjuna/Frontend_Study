interface StudyData {
    imageSrc: string;
    title: string;
    mentor: string;
    day: string;
    startTime: string;
    endTime: string;
    level: string;
    stack: string[];
    campus: string;
    description: string;
    isRecruiting: boolean;
  } 

var storedStudy: string = window.localStorage.getItem("study");
if (!storedStudy) {
    window.location.href = "/";
}
else {
    
    var study: StudyData = JSON.parse(storedStudy);
    console.log(study);

    var main = document.querySelector("main");

    var image = document.createElement("img") as HTMLImageElement;
    image.src = study.imageSrc;
    image.alt = study.title;

    var title = document.createElement("h1") as HTMLElement;
    title.textContent = study.title;
    var infoWrapper = document.createElement("div") as HTMLDivElement;
    infoWrapper.setAttribute("id", "info-wrapper");

    var level = document.createElement("p") as HTMLElement;
    level.textContent = "📚  " + study.level;

    var campus = document.createElement("p") as HTMLElement;
    campus.textContent = "🏢  " + study.campus;

    var mentor = document.createElement("p") as HTMLElement;
    mentor.textContent = "👤  " + study.mentor;

    var stack = document.createElement("p") as HTMLElement;
    stack.textContent = "🔧  " + study.stack.join(", ");

    infoWrapper.append(level, campus, mentor, stack);

    var description = document.createElement("p") as HTMLElement;
    description.textContent = study.description;
    description.setAttribute("id", "description");

    main.append(image, title, infoWrapper, description);
}